//
//  NSNotification+extensions.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation

public extension Notification.Name {
    static let dragInteractionStateChanged = Notification.Name("dragInteractionStateChanged")
}
