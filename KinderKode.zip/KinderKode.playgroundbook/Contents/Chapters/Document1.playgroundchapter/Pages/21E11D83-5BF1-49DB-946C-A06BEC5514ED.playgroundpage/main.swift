//#-hidden-code
//
//  main.swift
//
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, for, func, if, let, var, while, in)
//#-code-completion(literal, show, literal, array, boolean, color, dictionary, image, string, integer, nil)
//#-code-completion(snippet, show, repeat, switch, protocol, enum, struct, class, return)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles, SpriteKit, Swift, UIKit)
//#-code-completion(identifier, show, (hue:saturation:brightness:alpha:), (image:), (image:columns:rows:), (image:columns:rows:isDynamic:name:), (image:name:), (red:green:blue:alpha:), (text:color:), (text:color:font:size:name:), (type:), (type:text:name:), (width:height:), (x:y:), AcademyEngravedLET, AmericanTypewriter, AppleSDGothicNeo, Arial, ArialRoundedMTBold, Avenir, AvenirNext, AvenirNextCondensed, Baskerville, Bodoni72, Bounce1, Bounce2, Bounce3, BradleyHand, Button, ButtonType, ChalkDuster, ChalkboardSE, Cochin, Color, Copperplate, Courier, CourierNew, Didot, Font, Futura, Georgia, GillSans, Graphic, Helvetica, HelveticaNeue, HiraginoMinchoProN, HiraginoSans, Impact, Joint, Label, MarkerFelt, Menlo, Noteworthy, Optima, Palatino, Papyrus, PartyLET, PingFangSC, PingFangTC, Point, SavoyeLET, Scene, Size, SnellRoundhand, Sprite, String, Superclarendon, SystemBoldItalic, SystemFontBlack, SystemFontBold, SystemFontHeavy, SystemFontLight, SystemFontMedium, SystemFontRegular, SystemFontSemibold, SystemFontThin, SystemFontUltraLight, SystemHeavyItalic, SystemItalic, Thonburi, TimesNewRoman, Touch, TrebuchetMS, Verdana, Zapfino, add(joint:), allowsRotation, allowsTouchInteraction, alpha, angle, angularDamping, angularVelocity, applyForce(x:y:duration:), applyImpulse(x:y:), arabic, area, aspectFitMaximum, aspectFitMinimum, audioPlayAction(fileNamed:), backgroundColor, backgroundColors, backgroundImage, beam, beep, blip, boing1, boing2, boing3, boop1, boop2, boop3, bottom, bounciness, buttonPress1, buttonType, capturesTouches, center, chinese, chineseHongKong, chineseTaiwan, circle(radius:color:), circle(radius:color:colors:), circlePoints(radius:count:), clang, clear(), clunk, collisionNotificationCategories, constrained, containing:, contentPresentation, crash, crystal, customShape(path:color:), customShape(path:color:colors:), czech, danish, defeat1, density, distance(from:), drag, drop, dutch, echobird, electricBeep1, electricBeep2, electricBeep3, electricBeep4, electricBeepFader, englishAustralia, englishIreland, englishSouthAfrica, englishUK, englishUS, explosionShort, fadeAlpha(by:duration:), fadeAlpha(to:duration:), fadeIn(after:), fadeOut(after:), finnish, firstTouch, fit(within:), fixed(from:to:at:), font, fontSize, force, frenchCanada, frenchFrance, friction, friendlyPassage, german, getGraphics(at:in:), getGraphics(named:), getGraphicsWithName(containing:), graphics, greek, green, gridPoints(size:count:angle:), hasCollisionBorder, hebrew, height, helicopterWhoosh, hindi, horizontalGravity, hue:saturation:brightness:alpha:, hungarian, image, image(text:), image:, image:columns:rows:, image:columns:rows:isDynamic:name:, image:name:, indonesian, interactionCategory, isAffectedByGravity, isDynamic, isGridVisible, isResting, italian, japanese, joints, korean, laser1, laser2, laser3, left, limit(from:at:to:at:), line(length:thickness:color:), line(length:thickness:color:colors:), line(start:end:thickness:color:), line(start:end:thickness:color:colors:), linearDamping, location, machineGreeting1, machineGreeting2, machineGreeting3, mass, miss, move(to:duration:), moveBy(x:y:duration:), name, node, norwegian, onCollisionHandler, onGraphicTouchedHandler, onTouchMovedHandler, orbit(x:y:period:), orbitAction(x:y:period:), overlaid(with:offsetBy:), physicsBody, pi, pin(from:to:around:), pinned, place(_:), place(_:at:), place(_:at:anchoredTo:), place(at:), playSound(_:volume:), pleasantDing1, pleasantDing2, pleasantDing3, polish, polygon(radius:sides:color:), polygon(radius:sides:color:colors:), pop, pop1, pop2, portugueseBrazil, portuguesePortugal, position, powerUp1, powerUp2, powerUp3, powerUp4, powerup, pulsate(), pulsate(period:count:), puzzleJam, radiant, randomCharacter, randomIndex, randomItem, rectangle(width:height:cornerRadius:color:), rectangle(width:height:cornerRadius:color:colors:), red, red:green:blue:alpha:, remove(), remove(_:), remove(joint:), removeAction(forKey:), removeAllActions(), removeGraphics(named:), removeHandler(forInteraction:), removeJoints(named:), restituion, retroBass, retroCollide1, retroCollide2, retroCollide3, retroCollide4, retroCollide5, retroJump1, retroJump2, retroPowerUp1, retroPowerUp2, retroTwang1, retroTwang2, right, romanian, rotate(byAngle:duration:), rotate(toAngle:duration:), rotation, rotationalDrag, run(_:), run(_:key:), runAnimation(_:timePerFrame:numberOfTimes:), russian, scale, scale(by:duration:), scale(to:duration:), scaleX(by:y:duration:), scaleX(to:y:duration:), scaledImage(size:), setHandler(for:handler:), setOnCollisionHandler(_:), setOnTouchHandler(_:), setOnTouchMovedHandler(_:), setTintColor(_:blend:), setVelocity(x:y:), shake(duration:), shuffle(), shuffled(), size, sliding(from:to:at:axis:), slovak, somethingBad1, somethingBad2, somethingBad3, somethingBad4, somethingGood1, somethingGood2, somethingGood3, somethingGood4, somethingGood5, somethingGood6, somethingGood7, sonar, spanishMexico, spanishSpain, speak(text:), speak(text:withAccent:rate:pitch:completion:), spin(period:), splat, spring(from:at:to:at:), spring1, spring2, spring3, spring4, spriteA, spriteB, squarePoints(width:count:), squeak, star(radius:points:sharpness:color:), star(radius:points:sharpness:color:colors:), strangeWobble, strokeColor, strokeWidth, swedish, text, text:, text:color:, text:color:font:size:name:, textColor, thai, thud, tick, top, touch, touchCancelled, touchHandler, touchUp, tubeHit1, tubeHit2, tubeHit3, turkish, type:, type:text:name:, velocity, verticalGravity, victory1, victory2, victory3, victory4, wall, warble, warp, width, width:height:, x, x:y:, x:y:duration:, xScale, y, yScale, zap)
//#-code-completion(description, hide, "(hue: CGFloat, saturation: CGFloat, brightness: CGFloat, alpha: CGFloat)", "(x: CGFloat, y: CGFloat)", "(x: Float, y: Float)", "(width: CGFloat, height: CGFloat)", "(width: Float, height: Float)", "(point: CGPoint)", "(from: Decoder) throws", "(music: Music, volume: Int)", "playMusic(music: Music, volume: Int)", "(sound: Sound, volume: Int)", "playSound(sound: Sound, volume: Int)", "from(playgroundValue: PlaygroundValue)", "(sound: Sound)", "(sound: Sound, loopFireHandler: (() -> Void)?)")
//#-end-hidden-code
// Set up the LiveView
setUpLiveViewBackground(image: #imageLiteral(resourceName: "Photo 41.png"))
import AVFoundation
let synthesizer = AVSpeechSynthesizer()
var sum = Int()
var question = AVSpeechUtterance(string: "")
// create number line
let line = Graphic(image: #imageLiteral(resourceName: "Photo 42.png"))
scene.place(line, at: Point.zero)
line.setScale(0.4)
// Create a counter
let counter = Graphic.circle(radius: 50, color: #colorLiteral(red: 0.4550631046, green: 0.6557807326, blue: 0.9979295135, alpha: 1.0))
scene.place(counter, at: Point(x: 0, y: 100))
counter.isDraggable = true
    // create numbers on line

let zero = Graphic(image: #imageLiteral(resourceName: "Photo 43.png"))
zero.setScale(0.45)
scene.place(zero, at: Point(x: -380, y: -90))
zero.setHandler(for: .touch) { _ in
    if (sum == 0)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let one = Graphic(image: #imageLiteral(resourceName: "Photo 40.png"))
one.setScale(0.45)
scene.place(one, at: Point(x: -310, y: -90))
one.setHandler(for: .touch) { _ in
    if (sum == 1)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let two = Graphic(image: #imageLiteral(resourceName: "Photo 44.png"))
two.setScale(0.45)
scene.place(two, at: Point(x: -230, y: -90))
two.setHandler(for: .touch) { _ in
    if (sum == 2)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let three = Graphic(image: #imageLiteral(resourceName: "Photo 45.png"))
three.setScale(0.45)
scene.place(three, at: Point(x: -155, y: -90))
three.setHandler(for: .touch) { _ in
    if (sum == 3)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let four = Graphic(image: #imageLiteral(resourceName: "Photo 46.png"))
four.setScale(0.45)
scene.place(four, at: Point(x: -80, y: -90))
four.setHandler(for: .touch) { _ in
    if (sum == 4)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let five = Graphic(image: #imageLiteral(resourceName: "Photo 47.png"))
five.setScale(0.45)
scene.place(five, at: Point(x: -5, y: -90))
five.setHandler(for: .touch) { _ in
    if (sum == 5)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let six = Graphic(image: #imageLiteral(resourceName: "Photo 48.png"))
six.setScale(0.45)
scene.place(six, at: Point(x: 75, y: -90))
six.setHandler(for: .touch) { _ in
    if (sum == 6)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let seven = Graphic(image: #imageLiteral(resourceName: "Photo 49.png"))
seven.setScale(0.45)
scene.place(seven, at: Point(x: 150, y: -90))
seven.setHandler(for: .touch) { _ in
    if (sum == 7)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let eight = Graphic(image: #imageLiteral(resourceName: "Photo 50.png"))
eight.setScale(0.45)
scene.place(eight, at: Point(x: 225, y: -90))
eight.setHandler(for: .touch) { _ in
    if (sum == 8)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let nine = Graphic(image: #imageLiteral(resourceName: "Photo 51.png"))
nine.setScale(0.45)
scene.place(nine, at: Point(x: 300, y: -90))
nine.setHandler(for: .touch) { _ in
    if (sum == 9)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
let ten = Graphic(image: #imageLiteral(resourceName: "Photo 53.png"))
ten.setScale(0.45)
scene.place(ten, at: Point(x: 380, y: -90))
ten.setHandler(for: .touch) { _ in
    if (sum == 10)
    {var yay = AVSpeechUtterance(string:"Correct!")
        yay.rate = 0.4
        synthesizer.speak(yay)
        getProblem()
    }
    else
    {
        var no = AVSpeechUtterance(string:"Try again!")
        no.rate = 0.4
        synthesizer.speak(no)
    }
}
var intro = AVSpeechUtterance(string: "Move the blue counter with your finger or Apple Pencil to solve the problems!. . . Tap the number that is the answer. If you need to repeat the question, tap the speaker icon.")
intro.voice = AVSpeechSynthesisVoice(language: "en-US")
intro.rate = 0.4
synthesizer.speak(intro)
let repeatButton = Graphic(image: "🔊".image())
repeatButton.setScale(0.7)
scene.place(repeatButton, at: Point(x: 0, y: -200))
repeatButton.setHandler(for: .touch) { _ in
    synthesizer.speak(question)}
getProblem()
func getProblem()
{
    var one = Int.random(in: 0..<11)
    sum = Int.random(in:one..<11)
    var quest = "What is " + String(sum-one) + "+ " + String(one) + "?"
    question = AVSpeechUtterance(string: quest)
    question.preUtteranceDelay = 1.0
    question.rate = 0.4
    synthesizer.speak(question)
    //question = AVSpeechUtterance(string: String(sum))
}
