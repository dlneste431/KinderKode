//#-hidden-code
//
//  main.swift
//
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, for, func, if, let, var, while, in)
//#-code-completion(literal, show, literal, array, boolean, color, dictionary, image, string, integer, nil)
//#-code-completion(snippet, show, repeat, switch, protocol, enum, struct, class, return)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles, SpriteKit, Swift, UIKit)
//#-code-completion(identifier, show, (hue:saturation:brightness:alpha:), (image:), (image:columns:rows:), (image:columns:rows:isDynamic:name:), (image:name:), (red:green:blue:alpha:), (text:color:), (text:color:font:size:name:), (type:), (type:text:name:), (width:height:), (x:y:), AcademyEngravedLET, AmericanTypewriter, AppleSDGothicNeo, Arial, ArialRoundedMTBold, Avenir, AvenirNext, AvenirNextCondensed, Baskerville, Bodoni72, Bounce1, Bounce2, Bounce3, BradleyHand, Button, ButtonType, ChalkDuster, ChalkboardSE, Cochin, Color, Copperplate, Courier, CourierNew, Didot, Font, Futura, Georgia, GillSans, Graphic, Helvetica, HelveticaNeue, HiraginoMinchoProN, HiraginoSans, Impact, Joint, Label, MarkerFelt, Menlo, Noteworthy, Optima, Palatino, Papyrus, PartyLET, PingFangSC, PingFangTC, Point, SavoyeLET, Scene, Size, SnellRoundhand, Sprite, String, Superclarendon, SystemBoldItalic, SystemFontBlack, SystemFontBold, SystemFontHeavy, SystemFontLight, SystemFontMedium, SystemFontRegular, SystemFontSemibold, SystemFontThin, SystemFontUltraLight, SystemHeavyItalic, SystemItalic, Thonburi, TimesNewRoman, Touch, TrebuchetMS, Verdana, Zapfino, add(joint:), allowsRotation, allowsTouchInteraction, alpha, angle, angularDamping, angularVelocity, applyForce(x:y:duration:), applyImpulse(x:y:), arabic, area, aspectFitMaximum, aspectFitMinimum, audioPlayAction(fileNamed:), backgroundColor, backgroundColors, backgroundImage, beam, beep, blip, boing1, boing2, boing3, boop1, boop2, boop3, bottom, bounciness, buttonPress1, buttonType, capturesTouches, center, chinese, chineseHongKong, chineseTaiwan, circle(radius:color:), circle(radius:color:colors:), circlePoints(radius:count:), clang, clear(), clunk, collisionNotificationCategories, constrained, containing:, contentPresentation, crash, crystal, customShape(path:color:), customShape(path:color:colors:), czech, danish, defeat1, density, distance(from:), drag, drop, dutch, echobird, electricBeep1, electricBeep2, electricBeep3, electricBeep4, electricBeepFader, englishAustralia, englishIreland, englishSouthAfrica, englishUK, englishUS, explosionShort, fadeAlpha(by:duration:), fadeAlpha(to:duration:), fadeIn(after:), fadeOut(after:), finnish, firstTouch, fit(within:), fixed(from:to:at:), font, fontSize, force, frenchCanada, frenchFrance, friction, friendlyPassage, german, getGraphics(at:in:), getGraphics(named:), getGraphicsWithName(containing:), graphics, greek, green, gridPoints(size:count:angle:), hasCollisionBorder, hebrew, height, helicopterWhoosh, hindi, horizontalGravity, hue:saturation:brightness:alpha:, hungarian, image, image(text:), image:, image:columns:rows:, image:columns:rows:isDynamic:name:, image:name:, indonesian, interactionCategory, isAffectedByGravity, isDynamic, isGridVisible, isResting, italian, japanese, joints, korean, laser1, laser2, laser3, left, limit(from:at:to:at:), line(length:thickness:color:), line(length:thickness:color:colors:), line(start:end:thickness:color:), line(start:end:thickness:color:colors:), linearDamping, location, machineGreeting1, machineGreeting2, machineGreeting3, mass, miss, move(to:duration:), moveBy(x:y:duration:), name, node, norwegian, onCollisionHandler, onGraphicTouchedHandler, onTouchMovedHandler, orbit(x:y:period:), orbitAction(x:y:period:), overlaid(with:offsetBy:), physicsBody, pi, pin(from:to:around:), pinned, place(_:), place(_:at:), place(_:at:anchoredTo:), place(at:), playSound(_:volume:), pleasantDing1, pleasantDing2, pleasantDing3, polish, polygon(radius:sides:color:), polygon(radius:sides:color:colors:), pop, pop1, pop2, portugueseBrazil, portuguesePortugal, position, powerUp1, powerUp2, powerUp3, powerUp4, powerup, pulsate(), pulsate(period:count:), puzzleJam, radiant, randomCharacter, randomIndex, randomItem, rectangle(width:height:cornerRadius:color:), rectangle(width:height:cornerRadius:color:colors:), red, red:green:blue:alpha:, remove(), remove(_:), remove(joint:), removeAction(forKey:), removeAllActions(), removeGraphics(named:), removeHandler(forInteraction:), removeJoints(named:), restituion, retroBass, retroCollide1, retroCollide2, retroCollide3, retroCollide4, retroCollide5, retroJump1, retroJump2, retroPowerUp1, retroPowerUp2, retroTwang1, retroTwang2, right, romanian, rotate(byAngle:duration:), rotate(toAngle:duration:), rotation, rotationalDrag, run(_:), run(_:key:), runAnimation(_:timePerFrame:numberOfTimes:), russian, scale, scale(by:duration:), scale(to:duration:), scaleX(by:y:duration:), scaleX(to:y:duration:), scaledImage(size:), setHandler(for:handler:), setOnCollisionHandler(_:), setOnTouchHandler(_:), setOnTouchMovedHandler(_:), setTintColor(_:blend:), setVelocity(x:y:), shake(duration:), shuffle(), shuffled(), size, sliding(from:to:at:axis:), slovak, somethingBad1, somethingBad2, somethingBad3, somethingBad4, somethingGood1, somethingGood2, somethingGood3, somethingGood4, somethingGood5, somethingGood6, somethingGood7, sonar, spanishMexico, spanishSpain, speak(text:), speak(text:withAccent:rate:pitch:completion:), spin(period:), splat, spring(from:at:to:at:), spring1, spring2, spring3, spring4, spriteA, spriteB, squarePoints(width:count:), squeak, star(radius:points:sharpness:color:), star(radius:points:sharpness:color:colors:), strangeWobble, strokeColor, strokeWidth, swedish, text, text:, text:color:, text:color:font:size:name:, textColor, thai, thud, tick, top, touch, touchCancelled, touchHandler, touchUp, tubeHit1, tubeHit2, tubeHit3, turkish, type:, type:text:name:, velocity, verticalGravity, victory1, victory2, victory3, victory4, wall, warble, warp, width, width:height:, x, x:y:, x:y:duration:, xScale, y, yScale, zap)
//#-code-completion(description, hide, "(hue: CGFloat, saturation: CGFloat, brightness: CGFloat, alpha: CGFloat)", "(x: CGFloat, y: CGFloat)", "(x: Float, y: Float)", "(width: CGFloat, height: CGFloat)", "(width: Float, height: Float)", "(point: CGPoint)", "(from: Decoder) throws", "(music: Music, volume: Int)", "playMusic(music: Music, volume: Int)", "(sound: Sound, volume: Int)", "playSound(sound: Sound, volume: Int)", "from(playgroundValue: PlaygroundValue)", "(sound: Sound)", "(sound: Sound, loopFireHandler: (() -> Void)?)")
//#-end-hidden-code
import UIKit
import PlaygroundSupport
import AVFoundation
class CameraViewController:UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    var imageView = UIImageView()
    var shootButton = UIButton()
    let picker = UIImagePickerController()
    func playSound() { 
        let synthesizer = AVSpeechSynthesizer()
        let sounds = ["a", "b", "c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        let sentence = "Find something that starts with the letter: " + sounds[Int.random(in: 0..<26)]
        let utterance = AVSpeechUtterance(string: sentence)
        
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = 0.4
        synthesizer.speak(utterance)}
    @IBAction func shootPhoto(sender:UIButton){
        playSound()
        picker.sourceType = .camera
        picker.cameraCaptureMode = .photo
        picker.modalPresentationStyle = .fullScreen
        present(picker, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        picker.delegate = self
    }
    func setup(){
        imageView.image=#imageLiteral(resourceName: "Photo 55.png")
        imageView.contentMode = .scaleAspectFit
        imageView.frame = view.frame
        view.addSubview(imageView)
        var shootButton = UIButton(frame: CGRect(x: (view.frame.width/2)-100, y: 650, width: 200, height: 200))
        shootButton.setImage(#imageLiteral(resourceName: "Photo 56.png"),for: .normal)
        shootButton.addTarget(self, action: #selector(shootPhoto(sender:)), for: .touchUpInside)
        var shootFrame = view.frame
        shootFrame.size = CGSize(width: shootFrame.width, height: shootFrame.height * 0.1)
        view.addSubview(shootButton)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let newImage = info[UIImagePickerController.InfoKey.originalImage.rawValue] as! UIImage
        imageView.image = newImage
        dismiss(animated: true, completion: nil)
    }
}
let cameraVC = CameraViewController()
PlaygroundPage.current.liveView = cameraVC
let intro = AVSpeechUtterance(string: "Click the red button to hear a new sound!")

intro.voice = AVSpeechSynthesisVoice(language: "en-US")
intro.rate = 0.4
let synthesizer = AVSpeechSynthesizer()
synthesizer.speak(intro)
