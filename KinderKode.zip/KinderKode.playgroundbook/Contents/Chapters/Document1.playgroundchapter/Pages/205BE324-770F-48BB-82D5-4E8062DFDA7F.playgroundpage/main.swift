//#-hidden-code
//
//  main.swift
//
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, for, func, if, let, var, while, in)
//#-code-completion(literal, show, literal, array, boolean, color, dictionary, image, string, integer, nil)
//#-code-completion(snippet, show, repeat, switch, protocol, enum, struct, class, return)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles, SpriteKit, Swift, UIKit)
//#-code-completion(identifier, show, (hue:saturation:brightness:alpha:), (image:), (image:columns:rows:), (image:columns:rows:isDynamic:name:), (image:name:), (red:green:blue:alpha:), (text:color:), (text:color:font:size:name:), (type:), (type:text:name:), (width:height:), (x:y:), AcademyEngravedLET, AmericanTypewriter, AppleSDGothicNeo, Arial, ArialRoundedMTBold, Avenir, AvenirNext, AvenirNextCondensed, Baskerville, Bodoni72, Bounce1, Bounce2, Bounce3, BradleyHand, Button, ButtonType, ChalkDuster, ChalkboardSE, Cochin, Color, Copperplate, Courier, CourierNew, Didot, Font, Futura, Georgia, GillSans, Graphic, Helvetica, HelveticaNeue, HiraginoMinchoProN, HiraginoSans, Impact, Joint, Label, MarkerFelt, Menlo, Noteworthy, Optima, Palatino, Papyrus, PartyLET, PingFangSC, PingFangTC, Point, SavoyeLET, Scene, Size, SnellRoundhand, Sprite, String, Superclarendon, SystemBoldItalic, SystemFontBlack, SystemFontBold, SystemFontHeavy, SystemFontLight, SystemFontMedium, SystemFontRegular, SystemFontSemibold, SystemFontThin, SystemFontUltraLight, SystemHeavyItalic, SystemItalic, Thonburi, TimesNewRoman, Touch, TrebuchetMS, Verdana, Zapfino, add(joint:), allowsRotation, allowsTouchInteraction, alpha, angle, angularDamping, angularVelocity, applyForce(x:y:duration:), applyImpulse(x:y:), arabic, area, aspectFitMaximum, aspectFitMinimum, audioPlayAction(fileNamed:), backgroundColor, backgroundColors, backgroundImage, beam, beep, blip, boing1, boing2, boing3, boop1, boop2, boop3, bottom, bounciness, buttonPress1, buttonType, capturesTouches, center, chinese, chineseHongKong, chineseTaiwan, circle(radius:color:), circle(radius:color:colors:), circlePoints(radius:count:), clang, clear(), clunk, collisionNotificationCategories, constrained, containing:, contentPresentation, crash, crystal, customShape(path:color:), customShape(path:color:colors:), czech, danish, defeat1, density, distance(from:), drag, drop, dutch, echobird, electricBeep1, electricBeep2, electricBeep3, electricBeep4, electricBeepFader, englishAustralia, englishIreland, englishSouthAfrica, englishUK, englishUS, explosionShort, fadeAlpha(by:duration:), fadeAlpha(to:duration:), fadeIn(after:), fadeOut(after:), finnish, firstTouch, fit(within:), fixed(from:to:at:), font, fontSize, force, frenchCanada, frenchFrance, friction, friendlyPassage, german, getGraphics(at:in:), getGraphics(named:), getGraphicsWithName(containing:), graphics, greek, green, gridPoints(size:count:angle:), hasCollisionBorder, hebrew, height, helicopterWhoosh, hindi, horizontalGravity, hue:saturation:brightness:alpha:, hungarian, image, image(text:), image:, image:columns:rows:, image:columns:rows:isDynamic:name:, image:name:, indonesian, interactionCategory, isAffectedByGravity, isDynamic, isGridVisible, isResting, italian, japanese, joints, korean, laser1, laser2, laser3, left, limit(from:at:to:at:), line(length:thickness:color:), line(length:thickness:color:colors:), line(start:end:thickness:color:), line(start:end:thickness:color:colors:), linearDamping, location, machineGreeting1, machineGreeting2, machineGreeting3, mass, miss, move(to:duration:), moveBy(x:y:duration:), name, node, norwegian, onCollisionHandler, onGraphicTouchedHandler, onTouchMovedHandler, orbit(x:y:period:), orbitAction(x:y:period:), overlaid(with:offsetBy:), physicsBody, pi, pin(from:to:around:), pinned, place(_:), place(_:at:), place(_:at:anchoredTo:), place(at:), playSound(_:volume:), pleasantDing1, pleasantDing2, pleasantDing3, polish, polygon(radius:sides:color:), polygon(radius:sides:color:colors:), pop, pop1, pop2, portugueseBrazil, portuguesePortugal, position, powerUp1, powerUp2, powerUp3, powerUp4, powerup, pulsate(), pulsate(period:count:), puzzleJam, radiant, randomCharacter, randomIndex, randomItem, rectangle(width:height:cornerRadius:color:), rectangle(width:height:cornerRadius:color:colors:), red, red:green:blue:alpha:, remove(), remove(_:), remove(joint:), removeAction(forKey:), removeAllActions(), removeGraphics(named:), removeHandler(forInteraction:), removeJoints(named:), restituion, retroBass, retroCollide1, retroCollide2, retroCollide3, retroCollide4, retroCollide5, retroJump1, retroJump2, retroPowerUp1, retroPowerUp2, retroTwang1, retroTwang2, right, romanian, rotate(byAngle:duration:), rotate(toAngle:duration:), rotation, rotationalDrag, run(_:), run(_:key:), runAnimation(_:timePerFrame:numberOfTimes:), russian, scale, scale(by:duration:), scale(to:duration:), scaleX(by:y:duration:), scaleX(to:y:duration:), scaledImage(size:), setHandler(for:handler:), setOnCollisionHandler(_:), setOnTouchHandler(_:), setOnTouchMovedHandler(_:), setTintColor(_:blend:), setVelocity(x:y:), shake(duration:), shuffle(), shuffled(), size, sliding(from:to:at:axis:), slovak, somethingBad1, somethingBad2, somethingBad3, somethingBad4, somethingGood1, somethingGood2, somethingGood3, somethingGood4, somethingGood5, somethingGood6, somethingGood7, sonar, spanishMexico, spanishSpain, speak(text:), speak(text:withAccent:rate:pitch:completion:), spin(period:), splat, spring(from:at:to:at:), spring1, spring2, spring3, spring4, spriteA, spriteB, squarePoints(width:count:), squeak, star(radius:points:sharpness:color:), star(radius:points:sharpness:color:colors:), strangeWobble, strokeColor, strokeWidth, swedish, text, text:, text:color:, text:color:font:size:name:, textColor, thai, thud, tick, top, touch, touchCancelled, touchHandler, touchUp, tubeHit1, tubeHit2, tubeHit3, turkish, type:, type:text:name:, velocity, verticalGravity, victory1, victory2, victory3, victory4, wall, warble, warp, width, width:height:, x, x:y:, x:y:duration:, xScale, y, yScale, zap)
//#-code-completion(description, hide, "(hue: CGFloat, saturation: CGFloat, brightness: CGFloat, alpha: CGFloat)", "(x: CGFloat, y: CGFloat)", "(x: Float, y: Float)", "(width: CGFloat, height: CGFloat)", "(width: Float, height: Float)", "(point: CGPoint)", "(from: Decoder) throws", "(music: Music, volume: Int)", "playMusic(music: Music, volume: Int)", "(sound: Sound, volume: Int)", "playSound(sound: Sound, volume: Int)", "from(playgroundValue: PlaygroundValue)", "(sound: Sound)", "(sound: Sound, loopFireHandler: (() -> Void)?)")
//#-end-hidden-code
import SpriteKit
import AVFoundation
setUpLiveViewBackground(image: #imageLiteral(resourceName: "Photo 11.png"))
    // set up first card
var letterone = ""
var lettertwo = ""
var letterthree = ""
var first = Graphic(image: #imageLiteral(resourceName: "Photo 12.png"))
scene.place(first, at: Point(x: -310, y: 0))
first.setScale(0.3)
first.setHandler(for: .touch) { _ in
    let number = Int.random(in: 0..<16)
    if(number == 0)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 13.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "v"
    }
    if(number == 1)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 14.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "j"
    }
    if(number == 2)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 15.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "c"
    }
    if(number == 3)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 17.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "l"
    }
    if(number == 4)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 18.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "w"
    }
    if(number == 5)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 19.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "k"
    }
    if(number == 6)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 20.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "s"
    }
    if(number == 7)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 21.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "r"
    }
    if(number == 8)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 22.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "qu"
    }
    if(number == 9)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 23.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "z"
    }
    if(number == 10)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 24.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "h"
    }
    if(number == 11)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 25.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "y"
    }
    if(number == 12)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 26.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "p"
    }
    if(number == 13)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 27.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "f"
    }
    if(number == 14)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 28.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "b"
    }
    if(number == 15)
    {
        first  = Graphic(image: #imageLiteral(resourceName: "Photo 29.png"))
        scene.place(first, at: Point(x: -310, y: 0))
        first.setScale(0.3)
        letterone = "m"
    }
}
    // set up center card
var vowel = Graphic(image: #imageLiteral(resourceName: "Photo 4.png"))
scene.place(vowel, at: Point(x: 0, y: 0))
vowel.setScale(0.3)
vowel.setHandler(for: .touch) { _ in
    let number = Int.random(in: 0..<5)
    if(number == 0)
    {
        vowel  = Graphic(image: #imageLiteral(resourceName: "Photo 6.png"))
        scene.place(vowel, at: Point(x: 0, y: 0))
        vowel.setScale(0.3)
        lettertwo = "a"
    }
    if(number == 1)
    {
        vowel  = Graphic(image: #imageLiteral(resourceName: "Photo 5.png"))
        scene.place(vowel, at: Point(x: 0, y: 0))
        vowel.setScale(0.3)
        lettertwo = "e"
    }
    if(number == 2)
    {
        vowel  = Graphic(image: #imageLiteral(resourceName: "Photo 7.png"))
        scene.place(vowel, at: Point(x: 0, y: 0))
        vowel.setScale(0.3)
        lettertwo = "i"
    }
    if(number == 3)
    {
        vowel = Graphic(image: #imageLiteral(resourceName: "Photo 8.png"))
        scene.place(vowel, at: Point(x: 0, y: 0))
        vowel.setScale(0.3)
        lettertwo = "u"
    }
    if(number == 4)
    {
        vowel  = Graphic(image: #imageLiteral(resourceName: "Photo 10.png"))
        scene.place(vowel, at: Point(x: 0, y: 0))
        vowel.setScale(0.3)
        lettertwo = "o"
    }
}
    // set up third card
var last = Graphic(image: #imageLiteral(resourceName: "Photo 12.png"))
scene.place(last, at: Point(x: 310, y: 0))
last.setScale(0.3)
last.setHandler(for: .touch) { _ in
    let number = Int.random(in: 0..<8)
    if(number == 0)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 28.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "b"
    }
    if(number == 1)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 29.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "m"
    }
    if(number == 2)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 26.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "p"
    }
    if(number == 3)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 30.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "g"
    }
    if(number == 4)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 31.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "n"
    }
    if(number == 5)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 32.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "t"
    }
    if(number == 6)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 33.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "x"
    }
    if(number == 7)
    {
        last = Graphic(image: #imageLiteral(resourceName: "Photo 34.png"))
        scene.place(last, at: Point(x: 310, y: 0))
        last.setScale(0.3)
        letterthree = "d"
    }
}
var intro = AVSpeechUtterance(string: "Tap each card to make a letter appear. . The vowels will be pink and the consonants will be yellow. . Say each sound and then B.L.E.N.D. blend the word together! . Is it a real or nonsense word? Tap the X or check mark to check what you know!")
intro.voice = AVSpeechSynthesisVoice(language: "en-US")
intro.rate = 0.35
let synthesizer = AVSpeechSynthesizer()
synthesizer.speak(intro)
var realwords = ["cub","cob","jab","job","lab","web","sob","sub","rib","rob","rub","bib","bob","hub","pub","fab","fib","mob","jam","cam","sum","rim","rum","ham","hem","hum","him","yam","pep","pip","pop","pup","fam","pom","cap","lap","lip","sap","sip","rap","rep","rip","zap","zip","hip","hop","yap","map","mop","jug","jog","lag","leg","log","lug","wag","wig","sag","rag","rig","rug","zag","zig","hog","hug","peg","pig","pug","fig","fog","bag","beg","big","bug","mug","van","can","con","win","sin","sun","son","ran","run","hen","yen","pan","pen","pin","pun","fan","fin","fun","ban","bin","man","men","vet","jet","jot","cat","cot","cut","lat","let","lit","lot","wet","wit","sat","sit","set","rat","rot","rut","quit","zit","hat","hit","hot","hut","yet","pat","pet","pit","pot","put","fat","fit","bat","bet","bit","bot","mat","met","vex","cod","lax","lad","lid","wax","wad","wed","kid","sax","sex","six","sad","rad","rid","rod","red","quad","hex","had","hid","pox","pad","pod","fax","fix","fox","fad","fed","box","bad","bed","bud","max","mix","mad"]
var real = Graphic(image: #imageLiteral(resourceName: "Photo 61.png"))
scene.place(real, at: Point(x: 320, y: -310))
real.setScale(0.15)
real.setHandler(for: .touch) { _ in
    var word = letterone+lettertwo+letterthree
    for i in realwords
    {
        if (i==word)
        {
            var sent = word + " is a real word!"
            intro = AVSpeechUtterance(string: sent)
            intro.voice = AVSpeechSynthesisVoice(language: "en-US")
            intro.rate = 0.35
            synthesizer.speak(intro)
            return;
        }
        
    }
    var sent = word + " is a nonsense word!"
    intro = AVSpeechUtterance(string: sent)
    intro.voice = AVSpeechSynthesisVoice(language: "en-US")
    intro.rate = 0.35
    synthesizer.speak(intro)
    return;
}
var nonsense = Graphic(image: #imageLiteral(resourceName: "Photo 62.png"))
scene.place(nonsense, at: Point(x: -340, y: -310))
nonsense.setScale(0.15)
nonsense.setHandler(for: .touch) { _ in
    var word = letterone+lettertwo+letterthree
    for i in realwords
    {
        if (i==word)
        {
            var sent = word + " is a real word!"
            intro = AVSpeechUtterance(string: sent)
            intro.voice = AVSpeechSynthesisVoice(language: "en-US")
            intro.rate = 0.35
            synthesizer.speak(intro)
            return;
        }
        
    }
    var sent = word + " is a nonsense word!"
    intro = AVSpeechUtterance(string: sent)
    intro.voice = AVSpeechSynthesisVoice(language: "en-US")
    intro.rate = 0.35
    synthesizer.speak(intro)
    return;
}
